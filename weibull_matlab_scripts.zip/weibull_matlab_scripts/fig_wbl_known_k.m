% pkg load statistics

c = 2.87;
twoc = 2*c;
num_mc_runs = 100000;
ln2 = log(2);
lnln2 = log(ln2);
lnpioversqrt6 = log(pi/sqrt(6));

n = 100;

etas = 2:0.05:16;
ks = [0.5 1 1.5];
for kloop = 1:length(ks),
for etaloop = 1:length(etas),

k = ks(kloop)
eta = etas(etaloop)

naive_count = 0;
sc_count = 0;
bic_count = 0;

for trial = 1:num_mc_runs,
trial;
x = wblrnd(eta,k,1,n);
sumx = sum(x);
sumlogx = sum(log(x));

wetahat = (sum(x .^ k) / n)^(1/k);

ll_weibull_6 = n*log(k / 6^k) ...
           + (k - 1) * sumlogx ...
           - sum((x ./ 6) .^ k);
ll_weibull_eta = n*log(k / wetahat^k) ...
           + (k - 1) * sumlogx ...
           - sum((x ./ wetahat) .^ k);

b_w1 = ceil(log2(max(wetahat,1/wetahat)));

bic_weibull_6 = -ll_weibull_6;
sc_weibull_6 = bic_weibull_6;

bic_weibull_eta = -ll_weibull_eta + (1/2)*log(n/(2*pi));
sc_weibull_eta = bic_weibull_eta ...
        + log(k) ...
        + log(2*b_w1) + lnln2 ...
        + (logstar(b_w1) + c) * ln2;    

if ll_weibull_eta > ll_weibull_6, naive_count = naive_count+1; end
if sc_weibull_eta < sc_weibull_6, sc_count = sc_count+1; end
if bic_weibull_eta < sc_weibull_6, bic_count = bic_count+1; end
end 
prob_naive_weibull(etaloop,kloop) = naive_count / num_mc_runs;
prob_sc_weibull(etaloop,kloop) = sc_count / num_mc_runs;
prob_bic_weibull(etaloop,kloop) = bic_count / num_mc_runs;
end
end

figure; plot(etas,100*prob_sc_weibull)
axis tight; grid
title('Probabilty of choosing one-parameter Weibull model')
ylabel('Percent')
xlabel('Scale parameter')
ax = gca;
exportgraphics(ax,'wbl_vary_known_k_sc.pdf') 

figure; plot(etas,100*prob_bic_weibull)
axis tight; grid
title('Probabilty of choosing one-parameter Weibull model')
ylabel('Percent')
xlabel('Scale parameter')
ax = gca;
exportgraphics(ax,'wbl_vary_known_k_bic.pdf') 
These MATLAB scripts generate the figures for the paper. The ones that use wbl_fit require the Statistics and Machine Learning toolbox. There is one script per figure. They can take a while to run; if you want to get a quick feel for a particular graph, you can lower the number of Monte Carlo runs in the variable set at the top of the code:

num_mc_runs = 100000;

These should be able to made to run in Octave, an open source tool that's mostly compatible with MATLAB with minimal difficulty. If you are using Octave, remove the % symbol that indicates a comment in front of the 

pkg load statistics 

line at the top of the file to load in Octave's statistics package. You will first need to type "pkg install statistics" at the command line. The plotting code may also require some tweaking, but the main code that creates the data to plot should run unmodified.

The mapping to files and figures is as follows:

1: fig_wbl_vary_k_0_4_n10.m
2: fig_wbl_vary_k_0p5_1p5_n100.m
3: fig_wbl_vary_eta_0p1_2.m4: fig_wbl_vary_eta_1_25.m
5: fig_wbl_vary_k_variant.m
6, 7: wbl_vary_known_k.m
8: fig_wbl_known_eta_k39: fig_wbl_known_eta_k1
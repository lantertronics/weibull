% pkg load statistics

c = 2.87;
twoc = 2*c;
num_mc_runs = 100000;
ln2 = log(2);
lnln2 = log(ln2);
lnpioversqrt6 = log(pi/sqrt(6));

n = 10

ks = 0.05:0.05:4;
etas = [0.5 1 2 3];
for kloop = 1:length(ks),
for etaloop = 1:length(etas),

k = ks(kloop)
eta = etas(etaloop)

naive_count = 0;
sc_count = 0;
bic_count = 0;

for trial = 1:num_mc_runs,
trial;
x = wblrnd(eta,k,1,n);
sumx = sum(x);
sumlogx = sum(log(x));
paramhat = wblfit(x);
wetahat = paramhat(1);
khat = paramhat(2);
eetahat = sumx/n;

ll_exp = -n*log(eetahat) -  sumx / eetahat;
ll_weibull = n*log(khat / wetahat^khat) ...
           + (khat - 1) * sumlogx ...
           - sum((x ./ wetahat) .^ khat);

b_exp = ceil(log2(max(eetahat,1/eetahat)));
b_weibull = ceil(log2(max(wetahat,1/wetahat)));
s = max(ceil(log2(khat)),0);

bic_exp = -ll_exp + (1/2)*log(n/(2*pi));
sc_exp = bic_exp ...
       + log(2*b_exp) + lnln2 ...
       + (logstar(b_exp) + c) * ln2;

bic_weibull = -ll_weibull + (2/2)*log(n/(2*pi));
sc_weibull = bic_weibull ...
        + s * ln2 ...
        + log(pi/sqrt(6)) ...
        + log(2*b_weibull) + lnln2 ...
        + (logstar(b_weibull)  ...
           + logstar(s) + twoc) * ln2;    

if ll_weibull > ll_exp, naive_count = naive_count+1; end
if sc_weibull < sc_exp, sc_count = sc_count+1; end
if bic_weibull < bic_exp, bic_count = bic_count+1; end
end 
prob_naive_weibull(kloop,etaloop) = naive_count / num_mc_runs;
prob_sc_weibull(kloop,etaloop) = sc_count / num_mc_runs;
prob_bic_weibull(kloop,etaloop) = bic_count / num_mc_runs;
end
end

cmap = lines;
figure; 
plot(ks,100*prob_sc_weibull(:,1),'--', ...
     ks,100*prob_sc_weibull(:,2),'-', ...
     ks,100*prob_sc_weibull(:,3),'-.', ...
     ks,100*prob_sc_weibull(:,4),':')
hold on
plot(ks,100*prob_bic_weibull(:,1),'--', ...
     ks,100*prob_bic_weibull(:,2),'-', ...
     ks,100*prob_bic_weibull(:,3),'-.', ...
     ks,100*prob_bic_weibull(:,4),':')     
hold off
axis tight; grid
title('Probabilty of choosing Weibull model')
ylabel('Percent')
xlabel('Shape parameter')
ax = gca;
exportgraphics(ax,'wbl_vary_k_0_4_n10.pdf') 
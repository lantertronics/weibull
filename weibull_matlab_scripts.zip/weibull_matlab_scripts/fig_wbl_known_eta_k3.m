% pkg load statistics

c = 2.87;
twoc = 2*c;
num_mc_runs = 100000;
ln2 = log(2);
lnln2 = log(ln2);
emgamma = 0.57721;
magic_const = 0.5 * log(pi^2/6 + (emgamma-1)^2);

n = 100;

ks = 1.5:0.01:5;
etas = [1];
for kloop = 1:length(ks),
for etaloop = 1:length(etas),

k = ks(kloop)
eta = etas(etaloop)
lneta = log(eta);

naive_count = 0;
sc_count = 0;
bic_count = 0;

for trial = 1:num_mc_runs,
trial;
x = wblrnd(eta,k,1,n);
sumx = sum(x);
sumlogx = sum(log(x));

avglogx = sum(log(x)) / n;
xdiveta = x / eta;

kinit = k;
deriv = @(k) -1/k + lneta - avglogx + ...
          sum((xdiveta .^ k) .* log(xdiveta)) / n;
khat = fzero(deriv,kinit);

ll_weibull_3 = n*log(3 / eta^3) ...
           + (3 - 1) * sumlogx ...
           - sum((x ./ eta) .^ 3);
ll_weibull_k = n*log(khat / eta^khat) ...
           + (khat - 1) * sumlogx ...
           - sum((x ./ eta) .^ khat);

s_1 = ceil(log2(max(khat,1/khat)));

bic_weibull_3 = -ll_weibull_3;
sc_weibull_3 = bic_weibull_3;

bic_weibull_k = -ll_weibull_k + (1/2)*log(n/(2*pi));
sc_weibull_k = bic_weibull_k ...
        + magic_const ...
        + log(2*s_1) + lnln2 ...
        + (logstar(s_1) + c) * ln2;    

if ll_weibull_k > ll_weibull_3, naive_count = naive_count+1; end
if sc_weibull_k < sc_weibull_3, sc_count = sc_count+1; end
if bic_weibull_k < sc_weibull_3, bic_count = bic_count+1; end
end 
prob_naive_weibull(kloop,etaloop) = naive_count / num_mc_runs;
prob_sc_weibull(kloop,etaloop) = sc_count / num_mc_runs;
prob_bic_weibull(kloop,etaloop) = bic_count / num_mc_runs;
end
end

figure; plot(ks,100*[prob_sc_weibull,prob_bic_weibull])
axis tight; grid
title('Probabilty of choosing one-parameter Weibull model')
ylabel('Percent')
xlabel('Shape parameter')
ax = gca;
exportgraphics(ax,'wbl_known_eta_k3.pdf') 
